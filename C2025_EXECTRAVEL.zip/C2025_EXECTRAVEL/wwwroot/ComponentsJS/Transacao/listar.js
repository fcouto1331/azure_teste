﻿const carregarTransacao = () => {
    fetch('../Transacao/ListarJson', {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        //.then(response => response.json())
        .then(response => {
            if (response.status === 401 || response.status === 403) {
                document.location.href = '../Autenticacao/Login';
                return;
            }
            else {
                return response.json()
            }
        })
        .then(responseData => {
            let registros = document.getElementById('registros');
            registros.innerHTML = '';
            if (responseData) {
                if (responseData.ret) {
                    const transacao = responseData.transacao;
                    if (transacao && transacao.length > 0) {
                        let tabela = '';
                        tabela += `<table class="table table-bordered"><caption>Total: ${transacao.length}</caption>`;
                        tabela += `<thead class="bg-light text-dark">
                        <tr>
                            <th style="width:20%">Código</th>
                            <th style="width:20%">Empresa</th>
                            <th>Mês</th>
                            <th>Ano</th>
                            <th>Período Inicial</th>
                            <th>Período Final</th>
                            <th>Cadastro</th>
                            <th>Cad. Atualizado</th>
                            <th>Ações</th>
                        </tr>
                    </thead><tbody>`;

                        transacao.forEach(item => {
                            tabela += `<tr>
                            <td>${item.guidId}</td>
                            <td>${item.empresaNome}</td>  
                            <td>${item.mes}</td>
                            <td>${item.ano}</td>
                            <td>${formatarData(item.periodoIni) ?? ''}</td>
                            <td>${formatarData(item.periodoFim) ?? ''}</td>
                            <td>${formatarData(item.transacaoDataCadastro) ?? ''}</td>
                            <td>${formatarData(item.transacaoDataAtualizacao) ?? ''}</td>
                            <td>
                                <button class="btn btn-primary btn-sm" onclick="showModalAtualizar('${item.guidId}')" title='Editar transação'>E</button>
                                <button class="btn btn-danger btn-sm" onclick="deletar('${item.guidId}')" title='Deletar transação'>D</button>
                                <button class="btn btn-warning btn-sm" onclick="showModalImportarDados('${item.id}')" title='Importação'>I</button>
                                <button class="btn btn-info btn-sm" onclick="showModalListarDados('${item.guidId}')" title='Relatório'>R</button>
                                <button class="btn btn-success btn-sm" onclick="window.open('../Transacao/GraficoDinamico?TransacaoId=${item.guidId}', '_blank')"  title='Gráfico'>G</button>
                            </td>
                        </tr>`;
                        });

                        tabela += '</tbody></table>';
                        registros.innerHTML = tabela;
                    } else {
                        registros.innerHTML = '<div>Nenhum encontrado.</div>';
                    }
                }
                else {
                    alert(`Erro response: ${responseData.msg}`);
                }
            }
        })
        .catch(error => {
            alert(`Erro: ${error}`)
        });
}

document.addEventListener('DOMContentLoaded', carregarTransacao);