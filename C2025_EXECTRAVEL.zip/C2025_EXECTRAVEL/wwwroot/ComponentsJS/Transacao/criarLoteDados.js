﻿const _modalCriarLoteDados = document.getElementById('modalCriarLoteDados');

const showModalImportarDados = (Id) => {
    fetch('../ComponentsHTML/Transacao/criarLoteDados.html', {
        method: 'GET',
        headers: {
            'Accept': 'application/text',
            'Content-Type': 'application/text'
        }
    })
        .then(response => response.text())
        .then(responseData => {
            if (responseData) {
                _modalCriarLoteDados.innerHTML = '';
                _modalCriarLoteDados.innerHTML = responseData;
                document.getElementById('TransacaoId').value = Id;
                let _modalInstance = bootstrap.Modal.getInstance(_modalCriarLoteDados);
                if (!_modalInstance) {
                    _modalInstance = new bootstrap.Modal(_modalCriarLoteDados);
                }
                _modalInstance.show();
            }
        })
        .catch(error => {
            alert(`Erro ${error}`);
        })
}

if (_modalCriarLoteDados) {
    _modalCriarLoteDados.addEventListener('hidden.bs.modal', () => {
        _modalCriarLoteDados.innerHTML = '';
    });
}

const validarCamposHTML5Lote = () => {
    let cond = true;

    let nomeSheet = document.getElementById('NomeSheet');
    if (!nomeSheet.checkValidity()) {
        nomeSheet.reportValidity(); 
        cond = false;
    }

    let arquivo = document.getElementById('Arquivo');
    if (!arquivo.checkValidity()) {
        arquivo.reportValidity();
        cond = false;
    }

    return cond;
}

const criarLoteDados = (event) => {
    event.preventDefault()

    if (validarCamposHTML5Lote()) {

        let arquivo = document.getElementById('Arquivo').files[0];
        let nomeSheet = document.getElementById('NomeSheet').value;
        let transacaoId = document.getElementById('TransacaoId').value;        

        const formData = new FormData();
        formData.append('Arquivo', arquivo);
        formData.append('NomeSheet', nomeSheet);
        formData.append('TransacaoId', parseInt(transacaoId));

        // const btn = document.getElementById('btnCriarLoteDados');
        const btn = event.currentTarget; // por ser dinâmico
        const originalContent = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>&nbsp;Processando...`;

        fetch('../Transacao/CriarLoteTransacaoDadosJson', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                // 'Content-Type' - Quando se usa FormData, não se deve definir manualmente o Content-Type. O próprio navegador define automaticamente o Content-Type com multipart/form-data e os boundaries corretos.
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        })
            //.then(response => response.json())
            .then(response => {
                if (response.status === 401 || response.status === 403) {
                    document.location.href = '../Autenticacao/Login';
                    return;
                }
                else {
                    return response.json()
                }
            })
            .then(responseData => {
                if (responseData) {
                    if (responseData.ret) {
                        alert(responseData.msg);

                        let _modalInstance = bootstrap.Modal.getInstance(_modalCriarLoteDados);
                        if (!_modalInstance) {
                            _modalInstance = new bootstrap.Modal(_modalCriarLoteDados);
                        }
                        _modalInstance.hide();

                        _modalCriarLoteDados.innerHTML = '';
                    }
                    else {
                        alert(`Erro response: ${responseData.msg}`);
                    }
                }
            })
            .catch(error => {
                alert(`Erro ${error}`);
            })
            .finally(() => {
                btn.disabled = false;
                btn.innerHTML = originalContent;
            });
    }
}