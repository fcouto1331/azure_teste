﻿function gerarImagem() {
    const elemento = document.getElementById('content');

    html2canvas(elemento).then(canvas => {
        const link = document.createElement('a');
        link.download = `EXECTRAVEL_${_transacaoId}_${pegarDataAtualComHoras()}.png` //'imagem.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
    });
}