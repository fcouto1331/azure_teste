﻿const carregarLoggers = () => {
    fetch('../PainelLoggers/ListarJson', {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        //.then(response => response.json())
        .then(response => {
            if (response.status === 401 || response.status === 403) {
                document.location.href = '../Autenticacao/Login';
                return;
            }
            else {
                return response.json()
            }
        })
        .then(responseData => {
            let registros = document.getElementById('registros');
            registros.innerHTML = '';
            if (responseData) {
                if (responseData.ret) {
                    const loggers = responseData.loggers;
                    if (loggers && loggers.length > 0) {
                        let tabela = '';
                        tabela += `<table class="table table-bordered"><caption>Total: ${loggers.length}</caption>`;
                        tabela += `<thead class="bg-light text-dark">
                            <tr>
                                <th style="width:20%">Cadastro</th>
                                <th style="width:60%">Exceção</th>
                            </tr>
                        </thead><tbody>`;

                        loggers.forEach(item => {
                            tabela += `<tr>
                            <td>${formatarData(item.loggersDataCadastro) ?? ''}</td>
                            <td><textarea class="form-control" rows="2">${decodeUnicode(item.loggersException)}</textarea></td>
                        </tr>`;
                        });

                        tabela += '</tbody></table>';
                        registros.innerHTML = tabela;
                    } else {
                        registros.innerHTML = '<div>Nenhum encontrado.</div>';
                    }
                }
                else {
                    alert(`Erro response: ${responseData.msg}`);
                }
            }
        })
        .catch(error => {
            alert(`Erro: ${error}`)
        });
}

document.addEventListener('DOMContentLoaded', carregarLoggers);