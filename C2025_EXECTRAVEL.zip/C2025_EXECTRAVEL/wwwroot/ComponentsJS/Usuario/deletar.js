﻿const deletar = (GuidId) => {
    if (window.confirm('Deseja realmente prosseguir?')) {
        fetch(`../Usuario/DeletarJson?GuidId=${encodeURIComponent(GuidId)}`, {
            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
            //.then(response => response.json())
            .then(response => {
                if (response.status === 401 || response.status === 403) {
                    document.location.href = '../Autenticacao/Login';
                    return;
                }
                else {
                    return response.json()
                }
            })
            .then(responseData => {
                if (responseData) {
                    if (responseData.ret) {
                        alert(responseData.msg);
                        carregarUsuario();
                    }
                    else {
                        alert(`Erro response: ${responseData.msg}`);
                    }
                }
            })
            .catch(error => {
                alert(`Erro: ${error}`);
            });
    }
}