﻿const _modalCriar = document.getElementById('modalCriar');

const showModalCriar = () => {
    fetch('../ComponentsHTML/Usuario/Criar.html', {
        method: 'GET',
        headers: {
            'Accept': 'application/text',
            'Content-Type': 'application/text'
        }
    })
        .then(response => response.text())
        .then(responseData => {
            if (responseData) {
                _modalCriar.innerHTML = '';
                _modalCriar.innerHTML = responseData;
                carregarEmpresa()
                let _modalInstance = bootstrap.Modal.getInstance(_modalCriar);
                if (!_modalInstance) {
                    _modalInstance = new bootstrap.Modal(_modalCriar);
                }
                _modalInstance.show();
            }
        })
        .catch(error => {
            alert(`Erro: ${error}`);
        })
}

if (_modalCriar) {
    _modalCriar.addEventListener('hidden.bs.modal', () => {
        _modalCriar.innerHTML = '';
    });
}

const _btnShowModalCriar = document.getElementById('btnShowModalCriar')
_btnShowModalCriar.addEventListener('click', showModalCriar)

const carregarEmpresa = () => {
    let select = document.getElementById('Empresa'); 
    if (select) {
        fetch('../Transacao/ListarEmpresaJson', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        })
            .then(response => response.json())
            .then(responseData => {
                select.innerHTML = '';
                if (responseData && responseData.ret) {
                    const empresa = responseData.empresa

                    let option = document.createElement('option');
                    option.value = "";
                    option.textContent = "Empresa.";
                    select.appendChild(option);

                    if (empresa && empresa.length > 0) {
                        empresa.forEach(item => {
                            let option = document.createElement('option');
                            option.value = item.id;
                            option.textContent = item.nome;
                            select.appendChild(option);
                        });
                    }
                }
            })
            .catch(error => {
                alert(`Erro. ${error}`);
            });
    }
}

const validarCamposHTML5 = () => {
    let cond = true;

    let mes = document.getElementById('UsuarioLogin');
    if (!mes.checkValidity()) {
        mes.reportValidity(); 
        cond = false;
    }

    let empresa = document.getElementById('Empresa');
    if (!empresa.checkValidity()) {
        empresa.reportValidity();
        cond = false;
    }

    let usuarioPerfil = document.getElementById('UsuarioPerfil');
    if (!usuarioPerfil.checkValidity()) {
        usuarioPerfil.reportValidity();
        cond = false;
    }

    return cond;
}

const Criar = (event) => {
    event.preventDefault()

    if (validarCamposHTML5()) {

        let usuarioLogin = document.getElementById('UsuarioLogin').value;
        let empresa = document.getElementById('Empresa').value;
        let usuarioPerfil = document.getElementById('UsuarioPerfil').value;

        let dados = {
            UsuarioLogin: usuarioLogin,
            EmpresaId: parseInt(empresa),
            UsuarioPerfil: usuarioPerfil
        }

        fetch('../Usuario/CriarJson', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(dados)
        })
            //.then(response => response.json())
            .then(response => {
                if (response.status === 401 || response.status === 403) {
                    document.location.href = '../Autenticacao/Login';
                    return;
                }
                else {
                    return response.json()
                }
            })
            .then(responseData => {
                if (responseData) {
                    if (responseData.ret) {
                        alert(responseData.msg);

                        let _modalInstance = bootstrap.Modal.getInstance(_modalCriar);
                        if (!_modalInstance) {
                            _modalInstance = new bootstrap.Modal(_modalCriar);
                        }
                        _modalInstance.hide();

                        _modalCriar.innerHTML = '';
                        carregarUsuario();
                    }
                    else {
                        alert(`Erro response: ${responseData.msg}`);
                    }
                }
            })
            .catch(error => {
                alert(`Erro ${error}`); 
            })
    }
}
