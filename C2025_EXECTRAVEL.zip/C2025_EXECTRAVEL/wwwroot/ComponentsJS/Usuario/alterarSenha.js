﻿const _modalAlterarSenha = document.getElementById('modalAlterarSenha');

const showModalAlterarSenha = (GuidId) => {
    fetch('../ComponentsHTML/Usuario/alterarSenha.html', {
        method: 'GET',
        headers: {
            'Accept': 'application/text',
            'Content-Type': 'application/text'
        }
    })
        .then(response => response.text())
        .then(responseData => {
            if (responseData) {
                _modalAlterarSenha.innerHTML = '';
                _modalAlterarSenha.innerHTML = responseData;
                document.getElementById("GuidId").value = GuidId; 
                let _modalInstance = bootstrap.Modal.getInstance(_modalAlterarSenha);
                if (!_modalInstance) {
                    _modalInstance = new bootstrap.Modal(_modalAlterarSenha);
                }
                _modalInstance.show();
            }
        })
        .catch(error => {
            alert(`Erro: ${error}`);
        })
}

if (_modalAlterarSenha) {
    _modalAlterarSenha.addEventListener('hidden.bs.modal', () => {
        _modalAlterarSenha.innerHTML = '';
    });
}

const validarCamposAlterarSenhaHTML5 = () => {
    let cond = true;

    let usuarioPassword = document.getElementById('UsuarioPassword');
    if (!usuarioPassword.checkValidity()) {
        usuarioPassword.reportValidity();
        cond = false;
    }

    return cond;
}

const alterarSenha = (event) => {
    event.preventDefault()

    if (validarCamposAlterarSenhaHTML5()) {

        let guidId = document.getElementById('GuidId').value;
        let usuarioPassword = document.getElementById('UsuarioPassword').value;

        let formData = new URLSearchParams();
        formData.append("GuidId", guidId);
        formData.append("UsuarioPassword", usuarioPassword);

        fetch('../Usuario/AlterarPasswordJson', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        })
            //.then(response => response.json())
            .then(response => {
                if (response.status === 401 || response.status === 403) {
                    document.location.href = '../Autenticacao/Login';
                    return;
                }
                else {
                    return response.json()
                }
            })
            .then(responseData => {
                if (responseData) {
                    if (responseData.ret) {
                        alert(responseData.msg);
                        let _modalInstance = bootstrap.Modal.getInstance(_modalAlterarSenha);
                        if (!_modalInstance) {
                            _modalInstance = new bootstrap.Modal(_modalAlterarSenha);
                        }
                        _modalInstance.hide();
                        _modalAlterarSenha.innerHTML = '';
                    }
                    else {
                        alert(`Erro response: ${responseData.msg}`);
                    }
                }
            })
            .catch(error => {
                alert(`Erro: ${error}`);
            })
    }
}
