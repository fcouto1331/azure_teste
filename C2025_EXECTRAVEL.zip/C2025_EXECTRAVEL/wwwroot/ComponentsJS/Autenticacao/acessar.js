﻿const carregarEmpresa = () => {
    let select = document.getElementById('Empresa');
    if (select) {
        fetch('../Transacao/ListarEmpresaJson', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        })
            .then(response => response.json())
            .then(responseData => {
                select.innerHTML = '';
                if (responseData && responseData.ret) {
                    const empresa = responseData.empresa

                    let option = document.createElement('option');
                    option.value = "";
                    option.textContent = "Empresa.";
                    select.appendChild(option);

                    if (empresa && empresa.length > 0) {
                        empresa.forEach(item => {
                            let option = document.createElement('option');
                            option.value = item.id;
                            option.textContent = item.nome;
                            select.appendChild(option);
                        });
                    }
                }
            })
            .catch(error => {
                alert(`Erro. ${error}`);
            });
    }
}

const validarCamposHTML5 = () => {
    let cond = true;

    let usuarioLogin = document.getElementById('UsuarioLogin');
    if (!usuarioLogin.checkValidity()) {
        usuarioLogin.reportValidity();
        cond = false;
    }

    let usuarioPassword = document.getElementById('UsuarioPassword');
    if (!usuarioPassword.checkValidity()) {
        usuarioPassword.reportValidity();
        cond = false;
    }

    let empresa = document.getElementById('Empresa');
    if (!empresa.checkValidity()) {
        empresa.reportValidity();
        cond = false;
    }

    return cond;
}

const Acessar = (event) => {
    event.preventDefault()

    if (validarCamposHTML5()) {

        let usuarioLogin = document.getElementById('UsuarioLogin').value;
        let usuarioPassword = document.getElementById('UsuarioPassword').value;
        let empresa = document.getElementById('Empresa').value;

        let formData = new URLSearchParams();
        formData.append("UsuarioLogin", usuarioLogin);
        formData.append("UsuarioPassword", usuarioPassword);
        formData.append("EmpresaId", empresa);

        fetch('../Autenticacao/LoginJson', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded'
                // Não consta Authorize
            },
            body: formData
        })
            .then(response => response.json())
            .then(responseData => {
                if (responseData && responseData.ret) {
                    document.location.href = '../Home/Index';
                }
                else {
                    alert(`${responseData.msg}`);
                }
            })
            .catch(error => {
                alert(`${error}`);
            })
    }
}


document.addEventListener("DOMContentLoaded", carregarEmpresa);