﻿const carregarUsuario = () => {
    fetch('../AcessoCliente/PainelDadosClienteJson', {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        //.then(response => response.json())
        .then(response => {
            if (response.status === 401 || response.status === 403) {
                document.location.href = '../Autenticacao/Login';
                return;
            }
            else {
                return response.json()
            }
        })
        .then(responseData => {
            let registros = document.getElementById('registros');
            registros.innerHTML = '';
            if (responseData) {
                if (responseData.ret) {
                    const usuario = responseData.usuario;
                    if (usuario && usuario.length > 0) {
                        let tabela = '';
                        tabela += `<table class="table table-bordered"><caption>Total: ${usuario.length}</caption>`;
                        tabela += `<thead class="bg-light text-dark">
                        <tr>
                            <th style="width:20%">Código</th>
                            <th>Empresa</th>
                            <th style="width:60%">Usuário</th>
                            <th>Perfil</th>
                            <th>Ativo</th>
                            <th>Cadastro</th>
                            <th>Ações</th>
                        </tr>
                    </thead><tbody>`;

                        usuario.forEach(item => {
                            tabela += `<tr>
                            <td>${item.guidId}</td>
                            <td>${item.empresaId}</td>  
                            <td>${item.usuarioLogin}</td>
                            <td>${item.usuarioPerfil}</td>
                            <td><input type="checkbox" ${item.usuarioStatus ? 'checked' : ''} id="UsuarioStatus_${item.guidId}" disabled /></td>
                            <td>${formatarData(item.usuarioDataCadastro) ?? ''}</td>
                            <td>
                                <button class="btn btn-primary btn-sm" onclick="showModalAlterarSenha('${item.guidId}')" title='Alterar senha'>A</button>
                            </td>
                        </tr>`;
                        });

                        tabela += '</tbody></table>';
                        registros.innerHTML = tabela;
                    } else {
                        registros.innerHTML = '<div>Nenhum encontrado.</div>';
                    }
                }
                else {
                    alert(`Erro response: ${responseData.msg}`);
                }
            }
        })
        .catch(error => {
            alert(`Erro: ${error}`)
        });
}

document.addEventListener('DOMContentLoaded', carregarUsuario);