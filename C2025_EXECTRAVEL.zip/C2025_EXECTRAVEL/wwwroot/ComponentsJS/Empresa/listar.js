﻿const carregarEmpresa = () => {
    fetch('../Empresa/ListarJson', {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        //.then(response => response.json())
        .then(response => {
            if (response.status === 401 || response.status === 403) {
                document.location.href = '../Autenticacao/Login';
                return;
            }
            else {
                return response.json()
            }
        })
        .then(responseData => {
            let registros = document.getElementById('registros');
            registros.innerHTML = '';
            if (responseData) {
                if (responseData.ret) {
                    const empresa = responseData.empresa;
                    if (empresa && empresa.length > 0) {
                        let tabela = '';
                        tabela += `<table class="table table-bordered"><caption>Total: ${empresa.length}</caption>`;
                        tabela += `<thead class="bg-light text-dark">
                        <tr>
                            <th style="width:20%">Código</th>
                            <th style="width:60%">Empresa</th>
                            <th>Ativo</th>
                            <th>Cadastro</th>
                        </tr>
                    </thead><tbody>`;

                        empresa.forEach(item => {
                            tabela += `<tr>
                            <td>${item.guidId}</td>
                            <td><input type="text" class="form-control" id="Nome_${item.guidId}" required maxlength="100" value="${item.nome}" onblur="atualizar('${item.guidId}')" /></td>  
                            <td><input type="checkbox" ${item.empresaStatus ? 'checked' : ''} id="EmpresaStatus_${item.guidId}" onclick="ativar('${item.guidId}')" /></td>
                            <td>${formatarData(item.empresaDataCadastro) ?? ''}</td>
                        </tr>`;
                        });

                        tabela += '</tbody></table>';
                        registros.innerHTML = tabela;
                    } else {
                        registros.innerHTML = '<div>Nenhum encontrado.</div>';
                    }
                }
                else {
                    alert(`Erro response: ${responseData.msg}`);
                }
            }
        })
        .catch(error => {
            alert(`Erro: ${error}`)
        });
}

document.addEventListener('DOMContentLoaded', carregarEmpresa);