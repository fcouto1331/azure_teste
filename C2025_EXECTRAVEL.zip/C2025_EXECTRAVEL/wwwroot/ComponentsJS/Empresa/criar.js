﻿const _modalCriar = document.getElementById('modalCriar');

const showModalCriar = () => {
    fetch('../ComponentsHTML/Empresa/Criar.html', {
        method: 'GET',
        headers: {
            'Accept': 'application/text',
            'Content-Type': 'application/text'
        }
    })
        .then(response => response.text())
        .then(responseData => {
            if (responseData) {
                _modalCriar.innerHTML = '';
                _modalCriar.innerHTML = responseData;
                carregarEmpresa()
                let _modalInstance = bootstrap.Modal.getInstance(_modalCriar);
                if (!_modalInstance) {
                    _modalInstance = new bootstrap.Modal(_modalCriar);
                }
                _modalInstance.show();
            }
        })
        .catch(error => {
            alert(`Erro: ${error}`);
        })
}

if (_modalCriar) {
    _modalCriar.addEventListener('hidden.bs.modal', () => {
        _modalCriar.innerHTML = '';
    });
}

const _btnShowModalCriar = document.getElementById('btnShowModalCriar')
_btnShowModalCriar.addEventListener('click', showModalCriar)

const validarCamposHTML5 = () => {
    let cond = true;

    let mes = document.getElementById('Nome');
    if (!mes.checkValidity()) {
        mes.reportValidity(); 
        cond = false;
    }

    return cond;
}

const Criar = (event) => {
    event.preventDefault()

    if (validarCamposHTML5()) {

        let nome = document.getElementById('Nome').value;

        let dados = {
            Nome: nome
        }

        fetch('../Empresa/CriarJson', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(dados)
        })
            //.then(response => response.json())
            .then(response => {
                if (response.status === 401 || response.status === 403) {
                    document.location.href = '../Autenticacao/Login';
                    return;
                }
                else {
                    return response.json()
                }
            })
            .then(responseData => {
                if (responseData) {
                    if (responseData.ret) {
                        alert(responseData.msg);

                        let _modalInstance = bootstrap.Modal.getInstance(_modalCriar);
                        if (!_modalInstance) {
                            _modalInstance = new bootstrap.Modal(_modalCriar);
                        }
                        _modalInstance.hide();

                        _modalCriar.innerHTML = '';
                        carregarEmpresa();
                    }
                    else {
                        alert(`Erro response: ${responseData.msg}`);
                    }
                }
            })
            .catch(error => {
                alert(`Erro ${error}`);
            })
    }
}
