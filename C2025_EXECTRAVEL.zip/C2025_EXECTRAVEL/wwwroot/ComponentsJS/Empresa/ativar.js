﻿const ativar = (guidId) => {

    let checkbox = document.getElementById(`EmpresaStatus_${guidId}`);
    if (!checkbox) {
        console.error(`Elemento com id EmpresaStatus_${guidId} não encontrado.`);
        return;
    }
    const empresaStatus = checkbox.checked; // true ou false

    fetch(`../Empresa/AtivarJson?GuidId=${encodeURIComponent(guidId)}&EmpresaStatus=${encodeURIComponent(empresaStatus)}`, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        //.then(response => response.json())
        .then(response => {
            if (response.status === 401 || response.status === 403) {
                document.location.href = '../Autenticacao/Login';
                return;
            }
            else {
                return response.json()
            }
        })
        .then(responseData => {
            if (responseData) {
                if (responseData.ret) {
                    alert(responseData.msg);
                    carregarEmpresa();
                }
                else {
                    alert(`Erro response: ${responseData.msg}`);
                }
            }
        })
        .catch(error => {
            alert(`Erro: ${error}`)
        });
}