﻿const validarCampo = (campo) => {
    let cond = true;

    if (campo.value == '') cond = false;

    return cond;
}

const atualizar = (guidId) => {

    const campoNome = document.getElementById(`Nome_${guidId}`);
    let nome = document.getElementById(`Nome_${guidId}`).value;

    if (validarCampo(campoNome)) {

        fetch(`../Empresa/AtualizarJson?GuidId=${encodeURIComponent(guidId)}&Nome=${encodeURIComponent(nome)}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
            //.then(response => response.json())
            .then(response => {
                if (response.status === 401 || response.status === 403) {
                    document.location.href = '../Autenticacao/Login';
                    return;
                }
                else {
                    return response.json()
                }
            })
            .then(responseData => {
                if (responseData) {
                    if (responseData.ret) {
                        alert(responseData.msg);
                        carregarEmpresa();
                    }
                    else {
                        alert(`Erro response: ${responseData.msg}`);
                    }
                }
            })
            .catch(error => {
                alert(`Erro: ${error}`)
            });
    }
    else {
        // Define uma mensagem de validação personalizada
        campoNome.setCustomValidity("Por favor, preencha este campo corretamente.");

        // Dispara a caixa de diálogo de validação nativa
        campoNome.reportValidity();
    }
}

// Opcional: remover a mensagem de erro quando o usuário digitar algo válido
campoNome.addEventListener("input", function () {
    campoNome.setCustomValidity("");
});